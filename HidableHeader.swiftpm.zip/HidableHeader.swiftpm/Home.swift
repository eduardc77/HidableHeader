import SwiftUI
import Combine

struct Home: View {
    @State private var headerHeight: CGFloat = 0
    @State private var headerOffset: CGFloat = 0
    @State private var lastHeaderOffset: CGFloat = 0
    @State private var direction: SwipeDirection = .none
    
    /// The Value From Where It Shifted From Up/Down
    @State private var shiftOffset: CGFloat = 0
    
    let detector: CurrentValueSubject<CGFloat, Never>
    let publisher: AnyPublisher<CGFloat, Never>
    
    init() {
        let detector = CurrentValueSubject<CGFloat, Never>(.zero)
        self.publisher = detector
            .debounce(for: .seconds(0.1), scheduler: DispatchQueue.main)
            .dropFirst()
            .eraseToAnyPublisher()
        self.detector = detector
    }
    
    var body: some View {
        ScrollView(.vertical, showsIndicators: false) {
            thumbnails
                .padding(.top, headerHeight - safeArea().top)
            
                .offsetY { previous, current in
                    if previous > current {
                        // Scroll Up
                        if direction != .up && current < 0 {
                            shiftOffset = current - headerOffset
                            direction = .up
                            lastHeaderOffset = headerOffset
                        }
                        let offset = current < 0 ? (current - shiftOffset) : 0
                        // Check if it does not go over Header Height
                        headerOffset = (-offset < headerHeight ? (offset < 0 ? offset : 0) : -headerHeight)
                        
                    } else {
                        // Scroll Down
                        if direction != .down {
                            shiftOffset = current
                            direction = .down
                            lastHeaderOffset = headerOffset
                        }
                        let offset = lastHeaderOffset + (current - shiftOffset)
                        headerOffset = (offset > 0 ? 0 : offset)
                    }
                    detector.send(current)
                }
        }
        .coordinateSpace(name: "SCROLL")
        
        .onReceive(publisher) { _ in
            guard headerOffset < 0 else { return }
            direction = .none
            withAnimation {
                headerOffset = 0
            }
        }
        .overlay(
            VStack(spacing: 0) {
                headerView
                    .anchorPreference(key: HeaderBoundsKey.self, value: .bounds) { $0 }
                    .overlayPreferenceValue(HeaderBoundsKey.self) { value in
                        GeometryReader { geometry in
                            if let anchor = value {
                                Color.clear
                                    .onAppear {
                                        headerHeight = geometry[anchor].height
                                    }
                            }
                        }
                    }.offset(y: -headerOffset < headerHeight ? headerOffset : (headerOffset < 0 ? headerOffset : 0))
                
                Spacer()
            }
                .ignoresSafeArea(.all, edges: .top)
        )
    }
}

// MARK: - Subviews

private extension Home {
    
    var headerView: some View {
        VStack(spacing: 16) {
            VStack(spacing: 0) {
                HStack {
                    Rectangle()
                        .fill(Color.indigo.gradient)
                        .frame(width: 80, height: 30)
                    
                    HStack(spacing: 18) {
                        ForEach(["square.and.arrow.up", "bell.badge", "magnifyingglass"], id: \.self) { icon in
                            Button {
                                
                            } label: {
                                Image(systemName: icon)
                                    .resizable()
                                    .aspectRatio(contentMode: .fill)
                                    .frame(width: 18, height: 18)
                            }
                            .foregroundColor(.black)
                        }
                        Button {
                            
                        } label: {
                            Image(systemName: "person.crop.circle")
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 32, height: 32)
                        }
                    }.frame(maxWidth: .infinity, alignment: .trailing)
                }
                .padding(.bottom, 10)
                
                Divider().padding(.horizontal, -15)
            }
            .padding([.horizontal, .top], 15)
            
            tagView.padding(.bottom, 10)
        }
        .padding(.top, safeArea().top)
        .background(Color.white.ignoresSafeArea())
        .padding(.bottom, 20)
    }
    
    var tagView: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 10) {
                let tags = ["Top Results", "Artists", "Albums", "Songs", "Music Videos", "Composers"]
                
                ForEach(tags, id: \.self) { tag in
                    Button {
                        
                    } label: {
                        Text(tag)
                            .font(.callout)
                            .foregroundColor(.black)
                            .padding(.vertical,6)
                            .padding(.horizontal,12)
                            .background(
                                Capsule()
                                    .fill(.black.opacity(0.08))
                            )
                    }
                }
            }.padding(.horizontal,15)
        }
    }
    
    var thumbnails: some View {
        LazyVStack(spacing: 20) {
            let colors: [Color] = [.red, .green, .blue, .yellow, .indigo, .purple, .teal, .brown, .gray, .pink, .cyan, .mint, .orange]
            ForEach(0...50, id: \.self) { index in
                GeometryReader { proxy in
                    let size = proxy.size
                    
                    Button {
                        
                    } label: {
                        RoundedRectangle(cornerRadius: 25)
                            .fill(colors.randomElement()?.gradient ?? Color.black.gradient)
                            .frame(width: size.width, height: size.height)
                    }
                    .contextMenu {
                        Button {
                            
                        } label: {
                            Label("Add To Favorite", systemImage: "star")
                        }
                        
                        Button {
                            
                        } label: {
                            Label("Add to Playlist", systemImage: "text.insert")
                        }
                    }
                }
                .frame(height: 200)
                .padding(.horizontal)
            }
        }
    }
}

// MARK: - Swipe Direction Type

private extension Home {
    enum SwipeDirection {
        case up
        case down
        case none
    }
}


// MARK: - Previews

struct Home_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
